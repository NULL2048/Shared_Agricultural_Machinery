create definer = root@localhost view user_information as select `shared_agricultural_machinery_db`.`administrator`.`id`           AS `id`,
                                                                `shared_agricultural_machinery_db`.`administrator`.`password`     AS `password`,
                                                                `shared_agricultural_machinery_db`.`administrator`.`account_type` AS `account_type`
                                                         from `shared_agricultural_machinery_db`.`administrator`
                                                                  join `shared_agricultural_machinery_db`.`agricultural_machinery_management_department`
                                                                  join `shared_agricultural_machinery_db`.`peasant_household`
                                                         union
                                                         select `shared_agricultural_machinery_db`.`agricultural_machinery_management_department`.`id`           AS `id`,
                                                                `shared_agricultural_machinery_db`.`agricultural_machinery_management_department`.`password`     AS `password`,
                                                                `shared_agricultural_machinery_db`.`agricultural_machinery_management_department`.`account_type` AS `account_type`
                                                         from `shared_agricultural_machinery_db`.`agricultural_machinery_management_department`
                                                         union
                                                         select `shared_agricultural_machinery_db`.`peasant_household`.`id`           AS `id`,
                                                                `shared_agricultural_machinery_db`.`peasant_household`.`password`     AS `password`,
                                                                `shared_agricultural_machinery_db`.`peasant_household`.`account_type` AS `account_type`
                                                         from `shared_agricultural_machinery_db`.`peasant_household`
                                                         union
                                                         select `shared_agricultural_machinery_db`.`farm_machinery_operator`.`id`           AS `id`,
                                                                `shared_agricultural_machinery_db`.`farm_machinery_operator`.`password`     AS `password`,
                                                                `shared_agricultural_machinery_db`.`farm_machinery_operator`.`account_type` AS `account_type`
                                                         from `shared_agricultural_machinery_db`.`farm_machinery_operator`;

-- comment on column user_information.account_type not supported: 类型：农户，机手，农机管理部门，系统管理员

